import { useState } from 'react';
import { Button, Col, Flex, Form, Input, Row, Select, Tag, Typography } from 'antd';
import { Link } from 'react-router-dom';

import registerHeroUrl from '../../assets/images/registerHero.svg';
import { AuthSplitLayout } from '../../components/layout/AuthSplitLayout.jsx';
import { POSITION_OPTIONS, STATIC_USERS } from '../../data/staticData.js';
import { PATHS } from '../../routes/navConfig.js';
import { AUTH_ASIDE_STYLES, headingStyle } from '../../theme/sharedStyles.js';
import { BRAND_COLORS, MIN_PASSWORD_LENGTH } from '../../utils/constants.js';

const APPROVAL_STEPS = [
  'You fill in your details and your school position.',
  'An administrator reviews it, confirms your position and assigns your role.',
  'You get an in-app notice and can sign in once approved.',
];

/** Tighter spacing between form fields so the page fits without scrolling. */
const FIELD_STYLE = { marginBottom: 14 };

const STEP_STYLES = {
  list: {
    margin: 0,
    padding: 0,
    listStyle: 'none',
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  item: {
    display: 'flex',
    gap: 14,
    alignItems: 'flex-start',
    fontSize: 15,
    lineHeight: 1.5,
    color: 'rgba(255, 255, 255, 0.88)',
  },
  number: {
    width: 32,
    height: 32,
    flexShrink: 0,
    borderRadius: '50%',
    background: BRAND_COLORS.gold,
    color: BRAND_COLORS.text,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 700,
    fontSize: 14,
  },
};

/**
 * Navy side panel content explaining how account approval works.
 * @returns {JSX.Element}
 */
const RegisterAside = () => (
  <>
    <h1 style={{ ...AUTH_ASIDE_STYLES.title, fontSize: 30 }}>How account approval works</h1>
    <img
      src={registerHeroUrl}
      alt=""
      style={{ ...AUTH_ASIDE_STYLES.illustration, maxWidth: 420 }}
    />
    <ol style={STEP_STYLES.list}>
      {APPROVAL_STEPS.map((step, index) => (
        <li key={step} style={STEP_STYLES.item}>
          <span style={STEP_STYLES.number}>{index + 1}</span>
          <span>{step}</span>
        </li>
      ))}
    </ol>
  </>
);

/**
 * Confirmation shown after a registration is submitted.
 * @param {Object} props
 * @param {() => void} props.onShowForm - Shows the form again.
 * @returns {JSX.Element}
 */
const RegistrationSubmitted = ({ onShowForm }) => (
  <Flex vertical gap={20} align="flex-start">
    <Tag color="gold" variant="filled" style={{ fontWeight: 600 }}>
      Pending approval
    </Tag>
    <h2 style={headingStyle(28)}>Your account was submitted</h2>
    <Typography.Text type="secondary" style={{ fontSize: 15, lineHeight: 1.6 }}>
      An administrator will review it and assign your role. Until then, signing in will show that
      your account is pending.
    </Typography.Text>
    <Link to={PATHS.LOGIN}>
      <Button type="primary" size="large">
        Back to sign in
      </Button>
    </Link>
    <Button type="link" onClick={onShowForm} style={{ padding: 0 }}>
      Show the form again
    </Button>
  </Flex>
);

/**
 * Self-registration page. New accounts start as pending with no role (AGENTS.md §10).
 * @returns {JSX.Element}
 */
export const RegisterPage = () => {
  const [form] = Form.useForm();
  const [submitted, setSubmitted] = useState(false);

  /**
   * Static prototype: checks that the username and email aren't already used by a demo
   * account, then shows the "submitted" message. Nothing is saved.
   * @param {{ fullName: string, username: string, email: string, positionId: number, password: string, confirmPassword: string }} values - Form values.
   * @returns {void}
   */
  const handleFinish = ({ username, email }) => {
    const fieldErrors = [];
    if (STATIC_USERS.some((user) => user.username === username.trim())) {
      fieldErrors.push({ name: 'username', errors: ['Username is already taken'] });
    }
    if (STATIC_USERS.some((user) => user.email === email.trim())) {
      fieldErrors.push({ name: 'email', errors: ['Email is already registered'] });
    }
    if (fieldErrors.length) {
      form.setFields(fieldErrors);
      return;
    }
    form.resetFields();
    setSubmitted(true);
  };

  /**
   * Shows the registration form again.
   * @returns {void}
   */
  const handleShowForm = () => setSubmitted(false);

  if (submitted) {
    return (
      <AuthSplitLayout aside={<RegisterAside />}>
        <RegistrationSubmitted onShowForm={handleShowForm} />
      </AuthSplitLayout>
    );
  }

  return (
    <AuthSplitLayout aside={<RegisterAside />}>
      <Flex vertical gap={16}>
        <Flex vertical gap={6}>
          <h2 style={headingStyle(28)}>Create an account</h2>
          <Typography.Text type="secondary" style={{ fontSize: 15 }}>
            For SINHS personnel. Your role is assigned by an administrator.
          </Typography.Text>
        </Flex>

        <Form form={form} layout="vertical" requiredMark={false} onFinish={handleFinish}>
          <Form.Item
            style={FIELD_STYLE}
            label="Full name"
            name="fullName"
            rules={[{ required: true, whitespace: true, message: 'Enter your full name' }]}
          >
            <Input autoComplete="name" placeholder="First name, middle initial, last name" />
          </Form.Item>
          <Row gutter={16}>
            <Col xs={24} sm={12}>
              <Form.Item
                style={FIELD_STYLE}
                label="Username"
                name="username"
                rules={[{ required: true, whitespace: true, message: 'Choose a username' }]}
              >
                <Input autoComplete="username" placeholder="Choose a username" />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                style={FIELD_STYLE}
                label="Email"
                name="email"
                rules={[
                  { required: true, message: 'Enter your email' },
                  { type: 'email', message: 'Enter a valid email' },
                ]}
              >
                <Input autoComplete="email" placeholder="name@example.com" />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item
            style={FIELD_STYLE}
            label="Position"
            name="positionId"
            extra="Your position is shown on your profile. It doesn't decide what you can access."
            rules={[{ required: true, message: 'Select your position' }]}
          >
            <Select
              placeholder="Select your position"
              options={POSITION_OPTIONS}
              showSearch={{ optionFilterProp: 'label' }}
            />
          </Form.Item>
          <Row gutter={16}>
            <Col xs={24} sm={12}>
              <Form.Item
                style={FIELD_STYLE}
                label="Password"
                name="password"
                rules={[
                  { required: true, message: 'Enter a password' },
                  {
                    min: MIN_PASSWORD_LENGTH,
                    message: `At least ${MIN_PASSWORD_LENGTH} characters`,
                  },
                ]}
              >
                <Input.Password
                  autoComplete="new-password"
                  placeholder={`At least ${MIN_PASSWORD_LENGTH} characters`}
                />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                style={FIELD_STYLE}
                label="Confirm password"
                name="confirmPassword"
                dependencies={['password']}
                rules={[
                  { required: true, message: 'Re-enter your password' },
                  ({ getFieldValue }) => ({
                    validator: (_rule, value) =>
                      !value || getFieldValue('password') === value
                        ? Promise.resolve()
                        : Promise.reject(new Error('Passwords do not match')),
                  }),
                ]}
              >
                <Input.Password autoComplete="new-password" placeholder="Re-enter password" />
              </Form.Item>
            </Col>
          </Row>
          <Button type="primary" htmlType="submit" size="large" block>
            Submit for approval
          </Button>
        </Form>

        <Typography.Text type="secondary">
          Already have an account? <Link to={PATHS.LOGIN}>Sign in</Link>
        </Typography.Text>
      </Flex>
    </AuthSplitLayout>
  );
};
