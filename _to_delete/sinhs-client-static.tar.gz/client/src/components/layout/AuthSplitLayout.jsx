import { Grid } from 'antd';

import { BrandMark } from '../common/BrandMark.jsx';
import { BRAND_COLORS, SCHOOL } from '../../utils/constants.js';

const STYLES = {
  root: {
    minHeight: '100vh',
    display: 'flex',
    flexWrap: 'wrap',
    background: BRAND_COLORS.pageBg,
  },
  aside: {
    flex: '1 1 480px',
    boxSizing: 'border-box',
    background: BRAND_COLORS.navy,
    color: '#FFFFFF',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    gap: 48,
  },
  asideBody: { display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 520 },
  accent: {
    display: 'block',
    width: 56,
    height: 4,
    borderRadius: 2,
    background: BRAND_COLORS.gold,
  },
  footnote: { margin: 0, fontSize: 13, color: 'rgba(255, 255, 255, 0.72)' },
  main: {
    flex: '1 1 480px',
    boxSizing: 'border-box',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '48px 24px',
  },
  card: {
    width: '100%',
    maxWidth: 520,
    boxSizing: 'border-box',
    background: '#FFFFFF',
    border: `1px solid ${BRAND_COLORS.border}`,
    borderRadius: 20,
    boxShadow: '0 12px 32px rgba(15, 23, 42, 0.06)',
  },
};

/**
 * Two-column layout for login and registration: navy brand panel + form card.
 * Padding shrinks on small screens.
 * @param {Object} props
 * @param {import('react').ReactNode} props.aside - Content of the navy panel (below the brand).
 * @param {import('react').ReactNode} props.children - Form card content.
 * @returns {JSX.Element}
 */
export const AuthSplitLayout = ({ aside, children }) => {
  const screens = Grid.useBreakpoint();
  const isSmallScreen = !screens.sm;

  return (
    <div style={STYLES.root}>
      <section style={{ ...STYLES.aside, padding: isSmallScreen ? '32px 24px' : 56 }}>
        <BrandMark size="large" />
        <div style={STYLES.asideBody}>
          <span aria-hidden="true" style={STYLES.accent} />
          {aside}
        </div>
        <p style={STYLES.footnote}>
          {SCHOOL.name} · {SCHOOL.location} · Est. {SCHOOL.established}
        </p>
      </section>
      <main style={STYLES.main}>
        <div style={{ ...STYLES.card, padding: isSmallScreen ? '32px 24px' : '48px 56px' }}>
          {children}
        </div>
      </main>
    </div>
  );
};
