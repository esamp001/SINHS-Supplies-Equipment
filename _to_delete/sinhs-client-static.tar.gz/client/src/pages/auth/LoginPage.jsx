import { useState } from 'react';
import { Alert, Button, Checkbox, Divider, Flex, Form, Input, Typography } from 'antd';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import loginHeroUrl from '../../assets/images/loginHero.svg';
import { AuthSplitLayout } from '../../components/layout/AuthSplitLayout.jsx';
import { useAuth } from '../../hooks/useAuth.js';
import { DEMO_PASSWORD } from '../../data/staticData.js';
import { PATHS } from '../../routes/navConfig.js';
import { AUTH_ASIDE_STYLES, headingStyle } from '../../theme/sharedStyles.js';
import { ROLE_LABELS } from '../../utils/constants.js';

const ROLE_CHIP_STYLE = {
  padding: '6px 12px',
  borderRadius: 999,
  border: '1px solid rgba(232, 183, 26, 0.6)',
  fontSize: 13,
};

/**
 * Navy side panel content for the login page.
 * @returns {JSX.Element}
 */
const LoginAside = () => (
  <>
    <h1 style={AUTH_ASIDE_STYLES.title}>Supplies and equipment, tracked in one place.</h1>
    <p style={AUTH_ASIDE_STYLES.lead}>
      Request supplies, borrow equipment and keep stock accurate. What you can see and do depends on
      the role your administrator assigns.
    </p>
    <img style={AUTH_ASIDE_STYLES.illustration} src={loginHeroUrl} alt="" />
    <Flex wrap gap={8}>
      {Object.values(ROLE_LABELS).map((label) => (
        <span key={label} style={ROLE_CHIP_STYLE}>
          {label}
        </span>
      ))}
    </Flex>
  </>
);

/**
 * Sign-in page. On success the server sets the httpOnly cookie and the user goes to the dashboard.
 * @returns {JSX.Element}
 */
export const LoginPage = () => {
  const [form] = Form.useForm();
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [errorMessage, setErrorMessage] = useState('');
  const [showForgotNote, setShowForgotNote] = useState(false);

  /**
   * Checks the credentials and redirects to the page the user came from (or the dashboard).
   * @param {{ username: string, password: string, rememberMe: boolean }} values - Form values.
   * @returns {void}
   */
  const handleFinish = (values) => {
    setErrorMessage('');
    try {
      signIn(values);
      navigate(location.state?.from || PATHS.DASHBOARD, { replace: true });
    } catch (error) {
      setErrorMessage(error.message);
    }
  };

  /**
   * Toggles the "forgot password" help note.
   * @returns {void}
   */
  const handleToggleForgot = () => setShowForgotNote((value) => !value);

  return (
    <AuthSplitLayout aside={<LoginAside />}>
      <Flex vertical gap={28}>
        <Flex vertical gap={8}>
          <h2 style={headingStyle(34)}>Sign in</h2>
          <Typography.Text type="secondary" style={{ fontSize: 15 }}>
            Use the account your administrator approved.
          </Typography.Text>
        </Flex>

        {errorMessage && <Alert type="error" showIcon title={errorMessage} />}

        <Form
          form={form}
          layout="vertical"
          size="large"
          requiredMark={false}
          initialValues={{ rememberMe: false }}
          onFinish={handleFinish}
        >
          <Form.Item
            label="Username"
            name="username"
            rules={[{ required: true, whitespace: true, message: 'Enter your username' }]}
          >
            <Input autoComplete="username" placeholder="Enter your username" />
          </Form.Item>
          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true, message: 'Enter your password' }]}
          >
            <Input.Password autoComplete="current-password" placeholder="Enter your password" />
          </Form.Item>
          <Flex wrap align="center" justify="space-between" gap={12} style={{ marginBottom: 16 }}>
            <Form.Item name="rememberMe" valuePropName="checked" noStyle>
              <Checkbox>Keep me signed in</Checkbox>
            </Form.Item>
            <Button
              type="link"
              onClick={handleToggleForgot}
              aria-expanded={showForgotNote}
              style={{ padding: 0 }}
            >
              Forgot password?
            </Button>
          </Flex>
          {showForgotNote && (
            <Alert
              type="warning"
              title="Ask your administrator to reset your password. You'll be asked to set a new one the next time you sign in."
              style={{ marginBottom: 16 }}
            />
          )}
          <Button type="primary" htmlType="submit" block>
            Sign in
          </Button>
        </Form>

        <Divider style={{ margin: 0 }} />
        <Typography.Text type="secondary">
          New here? <Link to={PATHS.REGISTER}>Create an account</Link>. An administrator reviews it
          and assigns your role before you can sign in.
        </Typography.Text>

        <Alert
          type="info"
          title="Prototype demo accounts"
          description={`Usernames: admin, custodian, staff (pending: liza.bautista) · Password: ${DEMO_PASSWORD}`}
        />
      </Flex>
    </AuthSplitLayout>
  );
};
