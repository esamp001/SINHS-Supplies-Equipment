import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * Vite configuration for the SINHS client.
 * Default export is required by Vite (allowed exception in AGENTS.md §12.3).
 * The `/api` proxy is used once the Express server exists (VITE_USE_MOCKS=false).
 */
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
});
