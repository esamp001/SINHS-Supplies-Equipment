import { Badge, Button, Flex, Grid, Layout, Tooltip } from 'antd';
import { BellOutlined, MenuOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import { BrandMark } from '../common/BrandMark.jsx';
import { useAuth } from '../../hooks/useAuth.js';
import { useUnreadCount } from '../../hooks/useUnreadCount.js';
import { PATHS } from '../../routes/navConfig.js';
import { ROLE_LABELS } from '../../utils/constants.js';

const HEADER_BUTTON_STYLE = {
  color: '#FFFFFF',
  borderColor: 'rgba(255,255,255,0.4)',
  background: 'transparent',
};

/**
 * Top bar: brand, notification bell with unread count, user name/position/role, log out.
 * @param {Object} props
 * @param {() => void} props.onToggleNav - Toggles the side navigation (small screens).
 * @returns {JSX.Element}
 */
export const AppHeader = ({ onToggleNav }) => {
  const { user, signOut } = useAuth();
  const unreadCount = useUnreadCount();
  const navigate = useNavigate();
  const screens = Grid.useBreakpoint();
  const isWide = Boolean(screens.md);

  /**
   * Signs out and returns to the login page.
   * @returns {Promise<void>}
   */
  const handleLogout = async () => {
    await signOut();
    navigate(PATHS.LOGIN, { replace: true });
  };

  return (
    <Layout.Header className="sinhs-header">
      <Flex align="center" gap={12}>
        <Button
          type="text"
          icon={<MenuOutlined />}
          aria-label="Toggle navigation"
          onClick={onToggleNav}
          style={{ color: '#FFFFFF' }}
        />
        <BrandMark size="small" tagline={isWide ? 'Supplies & Equipment' : ''} />
      </Flex>
      <Flex align="center" gap={isWide ? 16 : 8}>
        <Tooltip title="Notifications">
          <Badge count={unreadCount} size="small" color="#E8B71A" style={{ color: '#0F172A' }}>
            <Button
              icon={<BellOutlined />}
              aria-label={`Notifications, ${unreadCount} unread`}
              style={HEADER_BUTTON_STYLE}
            />
          </Badge>
        </Tooltip>
        {isWide && (
          <div className="sinhs-header__user">
            <strong style={{ fontSize: 14 }}>{user.fullName}</strong>
            <span className="sinhs-header__user-meta">
              {user.positionName} · {ROLE_LABELS[user.roleCode]}
            </span>
          </div>
        )}
        <Button onClick={handleLogout} style={HEADER_BUTTON_STYLE}>
          Log out
        </Button>
      </Flex>
    </Layout.Header>
  );
};
