import { BrandMark } from '../common/BrandMark.jsx';
import { SCHOOL } from '../../utils/constants.js';

/**
 * Two-column layout for login and registration: navy brand panel + form card.
 * @param {Object} props
 * @param {import('react').ReactNode} props.aside - Content of the navy panel (below the brand).
 * @param {import('react').ReactNode} props.children - Form card content.
 * @returns {JSX.Element}
 */
export const AuthSplitLayout = ({ aside, children }) => (
  <div className="sinhs-auth">
    <section className="sinhs-auth__aside">
      <BrandMark size="large" />
      <div className="sinhs-auth__aside-body">
        <span aria-hidden="true" className="sinhs-auth__accent" />
        {aside}
      </div>
      <p className="sinhs-auth__footnote">
        {SCHOOL.name} · {SCHOOL.location} · Est. {SCHOOL.established}
      </p>
    </section>
    <main className="sinhs-auth__main">
      <div className="sinhs-auth__card">{children}</div>
    </main>
  </div>
);
