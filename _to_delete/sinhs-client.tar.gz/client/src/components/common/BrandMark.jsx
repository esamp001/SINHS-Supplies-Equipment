import sealUrl from '../../assets/images/sinhsSeal.svg';
import { SCHOOL } from '../../utils/constants.js';

/**
 * School seal with the "SINHS" name and system tagline. Used on auth pages and the header.
 * Replace `sinhsSeal.svg` with the official seal image when available.
 * @param {Object} props
 * @param {'large' | 'small'} [props.size='large'] - Large on auth pages, small in the header.
 * @param {string} [props.tagline] - Text under the name (empty hides it). Defaults to the system name.
 * @returns {JSX.Element}
 */
export const BrandMark = ({ size = 'large', tagline = SCHOOL.systemName }) => {
  const isLarge = size === 'large';
  const sealSize = isLarge ? 72 : 44;

  return (
    <div className="sinhs-brand">
      <img
        className="sinhs-brand__seal"
        src={sealUrl}
        alt={`${SCHOOL.name} seal`}
        width={sealSize}
        height={sealSize}
      />
      <div>
        <div className="sinhs-brand__name" style={{ fontSize: isLarge ? 24 : 18 }}>
          {SCHOOL.shortName}
        </div>
        {tagline && (
          <div className="sinhs-brand__tagline" style={{ fontSize: isLarge ? 14 : 12 }}>
            {tagline}
          </div>
        )}
      </div>
    </div>
  );
};
