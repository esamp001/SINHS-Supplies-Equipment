import { Card, Skeleton, Typography } from 'antd';

/**
 * Summary number card for the dashboard.
 * @param {Object} props
 * @param {string} props.label - Stat label.
 * @param {number | undefined} props.value - Stat value.
 * @param {string} [props.note] - Small helper text.
 * @param {boolean} [props.loading=false] - Shows a skeleton while loading.
 * @returns {JSX.Element}
 */
export const StatCard = ({ label, value, note, loading = false }) => (
  <Card styles={{ body: { padding: 20, display: 'flex', flexDirection: 'column', gap: 8 } }}>
    <Typography.Text strong type="secondary" style={{ fontSize: 13 }}>
      {label}
    </Typography.Text>
    {loading ? (
      <Skeleton.Input active size="small" style={{ width: 60 }} />
    ) : (
      <span className="sinhs-stat-value">{value ?? 0}</span>
    )}
    {note && (
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
        {note}
      </Typography.Text>
    )}
  </Card>
);
