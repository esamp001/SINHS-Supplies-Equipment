import { Card, Empty, Skeleton, Typography } from 'antd';
import { Link } from 'react-router-dom';

import { StatusTag } from './StatusTag.jsx';

const ROW_STYLE = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
  padding: '14px 20px',
  borderBottom: '1px solid #F1F5F9',
};

/**
 * Card with a short list of rows (main text, sub text, status tag) and a "View all" link.
 * @param {Object} props
 * @param {string} props.title - Panel title.
 * @param {string} props.viewAllPath - Route for the "View all" link.
 * @param {import('../../utils/types.js').PanelRow[]} props.rows - Rows to show.
 * @param {boolean} [props.loading=false] - Shows a loading state.
 * @returns {JSX.Element}
 */
export const ListPanel = ({ title, viewAllPath, rows, loading = false }) => {
  /**
   * Renders the panel body for the current state.
   * @returns {import('react').ReactNode}
   */
  const renderBody = () => {
    if (loading) return <Skeleton active style={{ padding: 20 }} />;
    if (!rows.length) {
      return (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="Nothing here"
          style={{ padding: 20 }}
        />
      );
    }
    return rows.map((row) => (
      <div key={row.id} style={ROW_STYLE}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 }}>
          <Typography.Text strong>{row.main}</Typography.Text>
          <Typography.Text type="secondary" style={{ fontSize: 13 }}>
            {row.sub}
          </Typography.Text>
        </div>
        <StatusTag status={row.status} />
      </div>
    ));
  };

  return (
    <Card
      title={title}
      extra={<Link to={viewAllPath}>View all</Link>}
      styles={{ body: { padding: 0 } }}
    >
      {renderBody()}
    </Card>
  );
};
