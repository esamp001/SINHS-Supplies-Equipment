import { Typography } from 'antd';

/**
 * Light-blue page banner with title, description, optional extras and an illustration.
 * @param {Object} props
 * @param {import('react').ReactNode} [props.eyebrow] - Content above the title (tag or breadcrumb).
 * @param {string} props.title - Page title.
 * @param {string} [props.description] - Supporting text.
 * @param {import('react').ReactNode} [props.children] - Extra content, e.g. action buttons.
 * @param {string} [props.illustrationUrl] - Decorative illustration URL.
 * @param {number} [props.illustrationWidth=300] - Illustration width in px.
 * @returns {JSX.Element}
 */
export const PageHero = ({
  eyebrow,
  title,
  description,
  children,
  illustrationUrl,
  illustrationWidth = 300,
}) => (
  <section className="sinhs-hero">
    <div className="sinhs-hero__body">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 640 }}>
        {eyebrow}
        <h1 className="sinhs-heading" style={{ fontSize: 32 }}>
          {title}
        </h1>
        {description && (
          <Typography.Text type="secondary" style={{ fontSize: 15 }}>
            {description}
          </Typography.Text>
        )}
      </div>
      {children}
    </div>
    {illustrationUrl && (
      <img
        className="sinhs-hero__illustration"
        src={illustrationUrl}
        alt=""
        style={{ width: illustrationWidth, flexBasis: illustrationWidth }}
      />
    )}
  </section>
);
