import { useCallback, useEffect, useMemo, useState } from 'react';

import { getCurrentUser, login, logout } from '../api/auth.api.js';
import { setUnauthorizedHandler } from '../api/httpClient.js';
import { AuthContext } from './authContext.js';

/**
 * Provides the signed-in user. The session lives in the server's httpOnly cookie;
 * this provider only keeps the user profile in memory (no browser storage).
 * @param {Object} props
 * @param {import('react').ReactNode} props.children - App content.
 * @returns {JSX.Element}
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    let active = true;

    /**
     * Restores the session from the auth cookie on page load.
     * @returns {Promise<void>}
     */
    const restoreSession = async () => {
      try {
        const currentUser = await getCurrentUser();
        if (active) setUser(currentUser);
      } catch {
        if (active) setUser(null);
      } finally {
        if (active) setInitializing(false);
      }
    };

    setUnauthorizedHandler(() => setUser(null));
    restoreSession();

    return () => {
      active = false;
    };
  }, []);

  /**
   * Signs in and stores the returned profile.
   * @param {{ username: string, password: string }} credentials - Login credentials.
   * @returns {Promise<import('../utils/types.js').AuthUser>} Signed-in user.
   */
  const signIn = useCallback(async (credentials) => {
    const signedInUser = await login(credentials);
    setUser(signedInUser);
    return signedInUser;
  }, []);

  /**
   * Signs out and clears the profile.
   * @returns {Promise<void>}
   */
  const signOut = useCallback(async () => {
    try {
      await logout();
    } finally {
      setUser(null);
    }
  }, []);

  const value = useMemo(
    () => ({ user, initializing, signIn, signOut }),
    [user, initializing, signIn, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
