import { createContext } from 'react';

/**
 * @typedef {Object} AuthContextValue
 * @property {import('../utils/types.js').AuthUser | null} user - Signed-in user, or null.
 * @property {boolean} initializing - True while the session is restored on page load.
 * @property {(credentials: { username: string, password: string }) => Promise<import('../utils/types.js').AuthUser>} signIn - Signs in.
 * @property {() => Promise<void>} signOut - Signs out.
 */

/**
 * Auth context. Use the `useAuth` hook instead of reading it directly.
 * @type {import('react').Context<AuthContextValue | null>}
 */
export const AuthContext = createContext(null);
