import homeAdminUrl from '../../assets/images/homeAdmin.svg';
import homeCustodianUrl from '../../assets/images/homeCustodian.svg';
import homeStaffUrl from '../../assets/images/homeStaff.svg';
import { PATHS } from '../../routes/navConfig.js';
import { ROLES } from '../../utils/constants.js';

/**
 * @typedef {Object} DashboardRoleConfig
 * @property {string} description - Text under the greeting.
 * @property {string} illustrationUrl - Hero illustration.
 * @property {Array<{ label: string, path: string }>} actions - Quick actions; the first is primary.
 * @property {Array<{ key: string, label: string, note: string }>} stats - Stat cards (key = summary.stats key).
 * @property {Array<{ key: string, title: string, path: string }>} panels - List panels (key = summary.panels key).
 */

/**
 * Per-role dashboard layout from the design prototype. Data comes from GET /dashboard/summary.
 * @type {Object<string, DashboardRoleConfig>}
 */
export const DASHBOARD_BY_ROLE = {
  [ROLES.ADMIN]: {
    description:
      'Approve new accounts, manage users and master data, and see every report. You can also act as custodian when needed.',
    illustrationUrl: homeAdminUrl,
    actions: [
      { label: 'Review new accounts', path: PATHS.USERS },
      { label: 'Add item type', path: PATHS.ITEM_TYPES },
      { label: 'Export report', path: PATHS.REPORTS },
    ],
    stats: [
      {
        key: 'pendingAccounts',
        label: 'Accounts awaiting approval',
        note: 'Self-registered personnel',
      },
      { key: 'pendingRequests', label: 'Pending requests', note: 'Waiting for a custodian' },
      { key: 'lowStockItems', label: 'Low-stock items', note: 'At or below reorder level' },
      { key: 'overdueEquipment', label: 'Overdue equipment', note: 'Past due date, not returned' },
    ],
    panels: [
      { key: 'pendingAccounts', title: 'New accounts awaiting approval', path: PATHS.USERS },
      { key: 'lowStock', title: 'Low stock', path: PATHS.ITEMS },
    ],
  },
  [ROLES.CUSTODIAN]: {
    description:
      'Review requests, release approved items, and keep stock and equipment records accurate.',
    illustrationUrl: homeCustodianUrl,
    actions: [
      { label: 'Review requests', path: PATHS.REQUESTS },
      { label: 'Stock in', path: PATHS.STOCK_TRANSACTIONS },
      { label: 'Record a return', path: PATHS.BORROWING },
    ],
    stats: [
      { key: 'requestsToReview', label: 'Requests to review', note: 'Supply and borrow requests' },
      { key: 'readyToRelease', label: 'Ready to release', note: 'Approved, not yet released' },
      { key: 'lowStockItems', label: 'Low-stock items', note: 'At or below reorder level' },
      { key: 'overdueEquipment', label: 'Overdue equipment', note: 'Past due date, not returned' },
    ],
    panels: [
      { key: 'requestsToReview', title: 'Requests awaiting your review', path: PATHS.REQUESTS },
      { key: 'overdueEquipment', title: 'Overdue equipment', path: PATHS.BORROWING },
    ],
  },
  [ROLES.STAFF]: {
    description:
      'Browse available items, request supplies, borrow equipment and follow the status of your requests.',
    illustrationUrl: homeStaffUrl,
    actions: [
      { label: 'Request supplies', path: PATHS.AVAILABLE_ITEMS },
      { label: 'Borrow equipment', path: PATHS.AVAILABLE_ITEMS },
    ],
    stats: [
      { key: 'myPendingRequests', label: 'My pending requests', note: 'Waiting for the custodian' },
      { key: 'myApprovedRequests', label: 'Approved, to pick up', note: 'Ready for release' },
      { key: 'myBorrowedItems', label: 'Items I have borrowed', note: 'Not yet returned' },
      { key: 'myDueSoon', label: 'Due soon', note: 'Return within 2 days' },
    ],
    panels: [
      { key: 'myRequests', title: 'My recent requests', path: PATHS.MY_REQUESTS },
      { key: 'myBorrowed', title: 'Borrowed by me', path: PATHS.MY_BORROWED },
    ],
  },
};
