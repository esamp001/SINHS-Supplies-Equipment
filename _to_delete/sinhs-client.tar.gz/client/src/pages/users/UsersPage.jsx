import { useState } from 'react';
import { Badge, Card, Flex, Tabs, Typography } from 'antd';

import homeAdminUrl from '../../assets/images/homeAdmin.svg';
import { PageHero } from '../../components/common/PageHero.jsx';
import { useUsers } from '../../hooks/useUsers.js';
import { USER_STATUS } from '../../utils/constants.js';
import { AllUsersTable } from './AllUsersTable.jsx';
import { PendingRegistrationsTable } from './PendingRegistrationsTable.jsx';
import { RolePermissionsTable } from './RolePermissionsTable.jsx';

const TAB_KEYS = Object.freeze({ PENDING: 'pending', USERS: 'users', MATRIX: 'matrix' });

/**
 * Users & roles page (Admin only): pending registrations, all users, role permissions.
 * @returns {JSX.Element}
 */
export const UsersPage = () => {
  const [activeTab, setActiveTab] = useState(TAB_KEYS.PENDING);
  const { data: pendingUsers, refetch: refetchPending } = useUsers({ status: USER_STATUS.PENDING });
  const pendingCount = pendingUsers?.length || 0;

  const tabItems = [
    {
      key: TAB_KEYS.PENDING,
      label: (
        <Flex align="center" gap={8}>
          Pending registrations
          <Badge count={pendingCount} size="small" />
        </Flex>
      ),
      children: <PendingRegistrationsTable onChanged={refetchPending} />,
    },
    { key: TAB_KEYS.USERS, label: 'All users', children: <AllUsersTable /> },
    { key: TAB_KEYS.MATRIX, label: 'Role permissions', children: <RolePermissionsTable /> },
  ];

  return (
    <>
      <PageHero
        eyebrow={
          <Typography.Text type="secondary" style={{ fontSize: 13 }}>
            Administration / Users &amp; accounts
          </Typography.Text>
        }
        title="Users & roles"
        description="Approve self-registered personnel, assign roles and manage accounts. Only Admins can open this page."
        illustrationUrl={homeAdminUrl}
        illustrationWidth={240}
      />
      <Card>
        <Tabs activeKey={activeTab} onChange={setActiveTab} items={tabItems} destroyOnHidden />
      </Card>
    </>
  );
};
