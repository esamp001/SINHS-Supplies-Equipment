import { useState } from 'react';
import { Alert, Button, Col, Flex, Form, Input, Row, Select, Tag, Typography } from 'antd';
import { Link } from 'react-router-dom';

import registerHeroUrl from '../../assets/images/registerHero.svg';
import { register } from '../../api/auth.api.js';
import { AuthSplitLayout } from '../../components/layout/AuthSplitLayout.jsx';
import { usePositions } from '../../hooks/usePositions.js';
import { PATHS } from '../../routes/navConfig.js';
import { MIN_PASSWORD_LENGTH } from '../../utils/constants.js';

const APPROVAL_STEPS = [
  'You fill in your details and your school position.',
  'An administrator reviews it, confirms your position and assigns your role.',
  'You get an in-app notice and can sign in once approved.',
];

/**
 * Navy side panel content explaining how account approval works.
 * @returns {JSX.Element}
 */
const RegisterAside = () => (
  <>
    <h1 className="sinhs-auth__title" style={{ fontSize: 34 }}>
      How account approval works
    </h1>
    <img
      className="sinhs-auth__illustration"
      src={registerHeroUrl}
      alt=""
      style={{ maxWidth: 420 }}
    />
    <ol className="sinhs-steps">
      {APPROVAL_STEPS.map((step, index) => (
        <li key={step} className="sinhs-steps__item">
          <span className="sinhs-steps__number">{index + 1}</span>
          <span>{step}</span>
        </li>
      ))}
    </ol>
  </>
);

/**
 * Confirmation shown after a registration is submitted.
 * @param {Object} props
 * @param {() => void} props.onShowForm - Shows the form again.
 * @returns {JSX.Element}
 */
const RegistrationSubmitted = ({ onShowForm }) => (
  <Flex vertical gap={20} align="flex-start">
    <Tag color="gold" variant="filled" style={{ fontWeight: 600 }}>
      Pending approval
    </Tag>
    <h2 className="sinhs-heading" style={{ fontSize: 28 }}>
      Your account was submitted
    </h2>
    <Typography.Text type="secondary" style={{ fontSize: 15, lineHeight: 1.6 }}>
      An administrator will review it and assign your role. Until then, signing in will show that
      your account is pending.
    </Typography.Text>
    <Link to={PATHS.LOGIN}>
      <Button type="primary" size="large">
        Back to sign in
      </Button>
    </Link>
    <Button type="link" onClick={onShowForm} style={{ padding: 0 }}>
      Show the form again
    </Button>
  </Flex>
);

/**
 * Self-registration page. New accounts start as pending with no role (AGENTS.md §10).
 * @returns {JSX.Element}
 */
export const RegisterPage = () => {
  const [form] = Form.useForm();
  const { positionOptions, loading: positionsLoading } = usePositions();
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  /**
   * Sends the registration and maps server field errors onto the form.
   * @param {{ fullName: string, username: string, email: string, positionId: number, password: string, confirmPassword: string }} values - Form values.
   * @returns {Promise<void>}
   */
  const handleFinish = async ({ confirmPassword: _confirmPassword, ...values }) => {
    setSubmitting(true);
    setErrorMessage('');
    try {
      await register(values);
      form.resetFields();
      setSubmitted(true);
    } catch (error) {
      const fieldErrors = Object.entries(error.errors || {});
      if (fieldErrors.length) {
        form.setFields(fieldErrors.map(([name, message]) => ({ name, errors: [message] })));
      } else {
        setErrorMessage(error.message);
      }
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Shows the registration form again.
   * @returns {void}
   */
  const handleShowForm = () => setSubmitted(false);

  if (submitted) {
    return (
      <AuthSplitLayout aside={<RegisterAside />}>
        <RegistrationSubmitted onShowForm={handleShowForm} />
      </AuthSplitLayout>
    );
  }

  return (
    <AuthSplitLayout aside={<RegisterAside />}>
      <Flex vertical gap={24}>
        <Flex vertical gap={8}>
          <h2 className="sinhs-heading" style={{ fontSize: 30 }}>
            Create an account
          </h2>
          <Typography.Text type="secondary" style={{ fontSize: 15 }}>
            For SINHS personnel. Your role is assigned by an administrator.
          </Typography.Text>
        </Flex>

        {errorMessage && <Alert type="error" showIcon title={errorMessage} />}

        <Form form={form} layout="vertical" requiredMark={false} onFinish={handleFinish}>
          <Form.Item
            label="Full name"
            name="fullName"
            rules={[{ required: true, whitespace: true, message: 'Enter your full name' }]}
          >
            <Input autoComplete="name" placeholder="First name, middle initial, last name" />
          </Form.Item>
          <Row gutter={16}>
            <Col xs={24} sm={12}>
              <Form.Item
                label="Username"
                name="username"
                rules={[{ required: true, whitespace: true, message: 'Choose a username' }]}
              >
                <Input autoComplete="username" placeholder="Choose a username" />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                label="Email"
                name="email"
                rules={[
                  { required: true, message: 'Enter your email' },
                  { type: 'email', message: 'Enter a valid email' },
                ]}
              >
                <Input autoComplete="email" placeholder="name@example.com" />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item
            label="Position"
            name="positionId"
            extra="Your position is shown on your profile. It doesn't decide what you can access."
            rules={[{ required: true, message: 'Select your position' }]}
          >
            <Select
              placeholder="Select your position"
              options={positionOptions}
              loading={positionsLoading}
              showSearch={{ optionFilterProp: 'label' }}
            />
          </Form.Item>
          <Row gutter={16}>
            <Col xs={24} sm={12}>
              <Form.Item
                label="Password"
                name="password"
                rules={[
                  { required: true, message: 'Enter a password' },
                  {
                    min: MIN_PASSWORD_LENGTH,
                    message: `At least ${MIN_PASSWORD_LENGTH} characters`,
                  },
                ]}
              >
                <Input.Password
                  autoComplete="new-password"
                  placeholder={`At least ${MIN_PASSWORD_LENGTH} characters`}
                />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item
                label="Confirm password"
                name="confirmPassword"
                dependencies={['password']}
                rules={[
                  { required: true, message: 'Re-enter your password' },
                  ({ getFieldValue }) => ({
                    validator: (_rule, value) =>
                      !value || getFieldValue('password') === value
                        ? Promise.resolve()
                        : Promise.reject(new Error('Passwords do not match')),
                  }),
                ]}
              >
                <Input.Password autoComplete="new-password" placeholder="Re-enter password" />
              </Form.Item>
            </Col>
          </Row>
          <Button type="primary" htmlType="submit" size="large" block loading={submitting}>
            Submit for approval
          </Button>
        </Form>

        <Typography.Text type="secondary">
          Already have an account? <Link to={PATHS.LOGIN}>Sign in</Link>
        </Typography.Text>
      </Flex>
    </AuthSplitLayout>
  );
};
