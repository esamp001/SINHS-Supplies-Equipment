import { useState } from 'react';
import { Alert, Button, Checkbox, Divider, Flex, Form, Input, Typography } from 'antd';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import loginHeroUrl from '../../assets/images/loginHero.svg';
import { AuthSplitLayout } from '../../components/layout/AuthSplitLayout.jsx';
import { useAuth } from '../../hooks/useAuth.js';
import { MOCK_DEMO_PASSWORD } from '../../mocks/mockDb.js';
import { PATHS } from '../../routes/navConfig.js';
import { ROLE_LABELS } from '../../utils/constants.js';

const SHOW_DEMO_ACCOUNTS = import.meta.env.VITE_USE_MOCKS !== 'false';

/**
 * Navy side panel content for the login page.
 * @returns {JSX.Element}
 */
const LoginAside = () => (
  <>
    <h1 className="sinhs-auth__title">Supplies and equipment, tracked in one place.</h1>
    <p className="sinhs-auth__lead">
      Request supplies, borrow equipment and keep stock accurate. What you can see and do depends on
      the role your administrator assigns.
    </p>
    <img className="sinhs-auth__illustration" src={loginHeroUrl} alt="" />
    <Flex wrap gap={8}>
      {Object.values(ROLE_LABELS).map((label) => (
        <span key={label} className="sinhs-role-chip">
          {label}
        </span>
      ))}
    </Flex>
  </>
);

/**
 * Sign-in page. On success the server sets the httpOnly cookie and the user goes to the dashboard.
 * @returns {JSX.Element}
 */
export const LoginPage = () => {
  const [form] = Form.useForm();
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showForgotNote, setShowForgotNote] = useState(false);

  /**
   * Submits credentials and redirects to the page the user came from (or the dashboard).
   * @param {{ username: string, password: string, rememberMe: boolean }} values - Form values.
   * @returns {Promise<void>}
   */
  const handleFinish = async (values) => {
    setSubmitting(true);
    setErrorMessage('');
    try {
      await signIn(values);
      navigate(location.state?.from || PATHS.DASHBOARD, { replace: true });
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Toggles the "forgot password" help note.
   * @returns {void}
   */
  const handleToggleForgot = () => setShowForgotNote((value) => !value);

  return (
    <AuthSplitLayout aside={<LoginAside />}>
      <Flex vertical gap={28}>
        <Flex vertical gap={8}>
          <h2 className="sinhs-heading" style={{ fontSize: 34 }}>
            Sign in
          </h2>
          <Typography.Text type="secondary" style={{ fontSize: 15 }}>
            Use the account your administrator approved.
          </Typography.Text>
        </Flex>

        {errorMessage && <Alert type="error" showIcon title={errorMessage} />}

        <Form
          form={form}
          layout="vertical"
          size="large"
          requiredMark={false}
          initialValues={{ rememberMe: false }}
          onFinish={handleFinish}
        >
          <Form.Item
            label="Username"
            name="username"
            rules={[{ required: true, whitespace: true, message: 'Enter your username' }]}
          >
            <Input autoComplete="username" placeholder="Enter your username" />
          </Form.Item>
          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true, message: 'Enter your password' }]}
          >
            <Input.Password autoComplete="current-password" placeholder="Enter your password" />
          </Form.Item>
          <Flex wrap align="center" justify="space-between" gap={12} style={{ marginBottom: 16 }}>
            <Form.Item name="rememberMe" valuePropName="checked" noStyle>
              <Checkbox>Keep me signed in</Checkbox>
            </Form.Item>
            <Button
              type="link"
              onClick={handleToggleForgot}
              aria-expanded={showForgotNote}
              style={{ padding: 0 }}
            >
              Forgot password?
            </Button>
          </Flex>
          {showForgotNote && (
            <Alert
              type="warning"
              title="Ask your administrator to reset your password. You'll be asked to set a new one the next time you sign in."
              style={{ marginBottom: 16 }}
            />
          )}
          <Button type="primary" htmlType="submit" block loading={submitting}>
            Sign in
          </Button>
        </Form>

        <Divider style={{ margin: 0 }} />
        <Typography.Text type="secondary">
          New here? <Link to={PATHS.REGISTER}>Create an account</Link>. An administrator reviews it
          and assigns your role before you can sign in.
        </Typography.Text>

        {SHOW_DEMO_ACCOUNTS && (
          <Alert
            type="info"
            title="Prototype demo accounts"
            description={`Usernames: admin, custodian, staff (pending: liza.bautista) · Password: ${MOCK_DEMO_PASSWORD}`}
          />
        )}
      </Flex>
    </AuthSplitLayout>
  );
};
