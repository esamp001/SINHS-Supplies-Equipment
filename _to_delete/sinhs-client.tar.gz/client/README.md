# SINHS Supplies & Equipment — Client (prototype)

React + Vite + Ant Design front end. Follows the conventions in `../AGENTS.md`.

## Run

```bash
cd client
npm install
cp .env.example .env   # optional; mocks are on by default
npm run dev            # http://localhost:5173
```

## Prototype mode (no backend yet)

With `VITE_USE_MOCKS=true` (the default), `src/api/httpClient.js` sends requests to the in-browser
mock API in `src/mocks/` instead of the network. Mock responses use the same REST envelope as the
real Express API, so pages and hooks won't change when the backend is ready — set
`VITE_USE_MOCKS=false` and start the server on port 4000 (Vite proxies `/api`).

Demo accounts (password `password123`): `admin`, `custodian`, `staff`, and `liza.bautista` (pending).

Mock data resets on page reload. The mock keeps the signed-in user ID in `sessionStorage` only to
simulate the server's httpOnly cookie; the real app never stores auth data in the browser.

## What's built

| Screen | Path | Roles |
|--------|------|-------|
| Sign in | `/login` | public |
| Create account (self-registration) | `/register` | public |
| Dashboard (per role) | `/dashboard` | all |
| Users & roles (pending registrations, all users, role permissions) | `/users` | admin |

Other menu items open a "coming soon" placeholder (configured in `src/routes/navConfig.js`).

## Notes

- `src/assets/images/sinhsSeal.svg` is a placeholder — replace it with the official school seal.
- Scripts: `npm run lint`, `npm run format`, `npm run build`.
